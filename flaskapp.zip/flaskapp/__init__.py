from flask import Flask, render_template, g, redirect, url_for, request, flash
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import LoginManager, login_user, login_required, logout_user
from .validation import *
from .models import User
import shelve


app = Flask(__name__)
app.config['SECRET_KEY']='7711d8a9e5973bcda814c99dbafcd7d6'

login_manager = LoginManager()
login_manager.init_app(app)

db = shelve.open('users.db', flag='c')
db["D001"] = ["David Tan", "davidtan@gmail.com", "1975-06-05",
              generate_password_hash("david")]

# For debugging purposes
# for k, v in db.items():
#     print(k, v)
db.close()


@login_manager.user_loader
def load_user(uid):
    db = shelve.open('users.db')
    if uid not in db:
        return None
    else:
        info = db[uid]
        user = User(uid, info[0], info[1], info[2])
        return user


@app.route('/')
def home():
    return render_template("home.html")


@app.route('/contactUs')
def contact_us():
    return render_template('contactUs.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == "POST":
        authenticated = True
        error = ""
        db = shelve.open('users.db')
        if not validate_nric(request.form["nric"]) and request.form["nric"] in db:
            error += "Invalid NRIC\n"
            authenticated = False
        db.close()

        if not validate_name(request.form["name"]):
            error += "Invalid name\n"
            authenticated = False

        if not validate_email(request.form["email"]):
            error += "Invalid email\n"
            authenticated = False

        if not validate_password(request.form["password"], request.form["confirm_password"]):
            error += "Passwords do not match\n"
            authenticated = False

        if authenticated:
            db = shelve.open('users.db', flag='w')
            db[request.form["nric"]] = [request.form["name"], request.form["email"], request.form["dob"],
                                        generate_password_hash(request.form["password"])]
            db.close()

            flash("Successful registration")

            user = User(request.form["nric"], request.form["name"], request.form["email"], request.form["dob"])
            login_user(user)

            return redirect(url_for("home"))

        flash(error)

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        db = shelve.open('users.db')
        error = ""
        authenticated = True
        if not validate_nric(request.form["nric"]) and request.form["nric"] not in db:
            error += "Invalid NRIC or no account associated with NRIC"
            authenticated = False
        else:
            pwdhash = db[request.form["nric"]][3]
            if not check_password_hash(pwdhash, request.form["password"]):
                error += "Incorrect password"
                authenticated = False
        db.close()

        if authenticated:
            user = load_user(request.form["nric"])
            login_user(user)
            return redirect(url_for('home'))

        flash(error)

    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("home"))


if __name__ == "__main__":
    app.run()
