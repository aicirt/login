from flask_login import UserMixin


class User(UserMixin):
    def __init__(self, uid, first_name, last_name, gender, dob, contact_number, email, address):
        self._uid = uid
        self._first_name = first_name
        self._last_name = last_name
        self._gender = gender
        self._dob = dob
        self._contact_number = contact_number
        self._email = email
        self._address = address

    def get_id(self):
        return self._uid

    def get_name(self):
        return self._first_name + " " + self._last_name

    def get_gender(self):
        return self._gender

    def get_dob(self):
        return self._dob

    def get_contact_number(self):
        return self._contact_number

    def get_email(self):
        return self._email

    def get_address(self):
        return self._address

    def is_doctor(self):
        return self._uid.startswith("D") and len(self._uid) == 4

    def is_admin(self):
        return self._uid.startswith("A") and len(self._uid) == 4
